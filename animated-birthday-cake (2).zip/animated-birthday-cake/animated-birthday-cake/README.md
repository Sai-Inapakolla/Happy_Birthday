# Animated Birthday Cake

A Pen created on CodePen.

Original URL: [https://codepen.io/aPenHasNoName/pen/VwawdMg](https://codepen.io/aPenHasNoName/pen/VwawdMg).

